﻿using Microsoft.AspNetCore.SignalR;

namespace Project2.Hubs
{
    public class MovieHub : Hub
    {
        // Có thể thêm các phương thức nếu cần truyền dữ liệu qua hub
    }
}